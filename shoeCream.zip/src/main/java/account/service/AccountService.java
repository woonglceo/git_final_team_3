package account.service;

public interface AccountService {

	
}
