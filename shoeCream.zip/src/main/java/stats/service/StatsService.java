package stats.service;

public interface StatsService {

}
