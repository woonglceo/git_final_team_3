package stats.service;

import org.springframework.stereotype.Service;

@Service
public class StatsServiceImpl implements StatsService {

}
