package address.service;

public interface AddressService {

}
