package address.service;

public class AddressServiceImpl implements AddressService {

}
